﻿namespace FormEkspedisi
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LabelResi = new MaterialSkin.Controls.MaterialLabel();
            this.materialSingleLineTextField1 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.materialLabel1 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel2 = new MaterialSkin.Controls.MaterialLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtNmaPengirim = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtAsal = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtTelpPengirim = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.materialLabel5 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel4 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel3 = new MaterialSkin.Controls.MaterialLabel();
            this.materialSingleLineTextField2 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtKodePos = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.materialLabel18 = new MaterialSkin.Controls.MaterialLabel();
            this.txtPenerima = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtTujuan = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtTlpPenerima = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.materialLabel6 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel7 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel8 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel9 = new MaterialSkin.Controls.MaterialLabel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.materialLabel15 = new MaterialSkin.Controls.MaterialLabel();
            this.txtBeratBrg = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.materialLabel14 = new MaterialSkin.Controls.MaterialLabel();
            this.txtJnsBrg = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtJmlhBrg = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtNmaBrg = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.materialLabel10 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel11 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel12 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel13 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel16 = new MaterialSkin.Controls.MaterialLabel();
            this.txtHarga = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.materialLabel17 = new MaterialSkin.Controls.MaterialLabel();
            this.btnSimpan = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btnBatal = new MaterialSkin.Controls.MaterialRaisedButton();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // LabelResi
            // 
            this.LabelResi.AutoSize = true;
            this.LabelResi.BackColor = System.Drawing.SystemColors.Window;
            this.LabelResi.Depth = 0;
            this.LabelResi.Font = new System.Drawing.Font("Roboto", 11F);
            this.LabelResi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.LabelResi.Location = new System.Drawing.Point(12, 83);
            this.LabelResi.MouseState = MaterialSkin.MouseState.HOVER;
            this.LabelResi.Name = "LabelResi";
            this.LabelResi.Size = new System.Drawing.Size(101, 19);
            this.LabelResi.TabIndex = 0;
            this.LabelResi.Text = "Nomor Resi : ";
            // 
            // materialSingleLineTextField1
            // 
            this.materialSingleLineTextField1.BackColor = System.Drawing.SystemColors.Window;
            this.materialSingleLineTextField1.Depth = 0;
            this.materialSingleLineTextField1.Hint = "";
            this.materialSingleLineTextField1.Location = new System.Drawing.Point(109, 83);
            this.materialSingleLineTextField1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialSingleLineTextField1.Name = "materialSingleLineTextField1";
            this.materialSingleLineTextField1.PasswordChar = '\0';
            this.materialSingleLineTextField1.SelectedText = "";
            this.materialSingleLineTextField1.SelectionLength = 0;
            this.materialSingleLineTextField1.SelectionStart = 0;
            this.materialSingleLineTextField1.Size = new System.Drawing.Size(117, 23);
            this.materialSingleLineTextField1.TabIndex = 1;
            this.materialSingleLineTextField1.UseSystemPasswordChar = false;
            // 
            // materialLabel1
            // 
            this.materialLabel1.AutoSize = true;
            this.materialLabel1.BackColor = System.Drawing.SystemColors.Window;
            this.materialLabel1.Depth = 0;
            this.materialLabel1.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel1.Location = new System.Drawing.Point(333, 83);
            this.materialLabel1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel1.Name = "materialLabel1";
            this.materialLabel1.Size = new System.Drawing.Size(74, 19);
            this.materialLabel1.TabIndex = 2;
            this.materialLabel1.Text = "Tanggal : ";
            // 
            // materialLabel2
            // 
            this.materialLabel2.AutoSize = true;
            this.materialLabel2.BackColor = System.Drawing.SystemColors.Window;
            this.materialLabel2.Depth = 0;
            this.materialLabel2.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel2.Location = new System.Drawing.Point(3, 0);
            this.materialLabel2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel2.Name = "materialLabel2";
            this.materialLabel2.Size = new System.Drawing.Size(107, 19);
            this.materialLabel2.TabIndex = 5;
            this.materialLabel2.Text = "Data Pengirim ";
            this.materialLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Window;
            this.panel1.Controls.Add(this.txtNmaPengirim);
            this.panel1.Controls.Add(this.txtAsal);
            this.panel1.Controls.Add(this.txtTelpPengirim);
            this.panel1.Controls.Add(this.materialLabel5);
            this.panel1.Controls.Add(this.materialLabel4);
            this.panel1.Controls.Add(this.materialLabel3);
            this.panel1.Controls.Add(this.materialLabel2);
            this.panel1.Location = new System.Drawing.Point(34, 130);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(259, 139);
            this.panel1.TabIndex = 4;
            // 
            // txtNmaPengirim
            // 
            this.txtNmaPengirim.BackColor = System.Drawing.SystemColors.Window;
            this.txtNmaPengirim.Depth = 0;
            this.txtNmaPengirim.Hint = "";
            this.txtNmaPengirim.Location = new System.Drawing.Point(101, 37);
            this.txtNmaPengirim.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtNmaPengirim.Name = "txtNmaPengirim";
            this.txtNmaPengirim.PasswordChar = '\0';
            this.txtNmaPengirim.SelectedText = "";
            this.txtNmaPengirim.SelectionLength = 0;
            this.txtNmaPengirim.SelectionStart = 0;
            this.txtNmaPengirim.Size = new System.Drawing.Size(117, 23);
            this.txtNmaPengirim.TabIndex = 10;
            this.txtNmaPengirim.UseSystemPasswordChar = false;
            // 
            // txtAsal
            // 
            this.txtAsal.BackColor = System.Drawing.SystemColors.Window;
            this.txtAsal.Depth = 0;
            this.txtAsal.Hint = "";
            this.txtAsal.Location = new System.Drawing.Point(101, 101);
            this.txtAsal.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtAsal.Name = "txtAsal";
            this.txtAsal.PasswordChar = '\0';
            this.txtAsal.SelectedText = "";
            this.txtAsal.SelectionLength = 0;
            this.txtAsal.SelectionStart = 0;
            this.txtAsal.Size = new System.Drawing.Size(117, 23);
            this.txtAsal.TabIndex = 9;
            this.txtAsal.UseSystemPasswordChar = false;
            // 
            // txtTelpPengirim
            // 
            this.txtTelpPengirim.BackColor = System.Drawing.SystemColors.Window;
            this.txtTelpPengirim.Depth = 0;
            this.txtTelpPengirim.Hint = "";
            this.txtTelpPengirim.Location = new System.Drawing.Point(101, 68);
            this.txtTelpPengirim.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtTelpPengirim.Name = "txtTelpPengirim";
            this.txtTelpPengirim.PasswordChar = '\0';
            this.txtTelpPengirim.SelectedText = "";
            this.txtTelpPengirim.SelectionLength = 0;
            this.txtTelpPengirim.SelectionStart = 0;
            this.txtTelpPengirim.Size = new System.Drawing.Size(117, 23);
            this.txtTelpPengirim.TabIndex = 8;
            this.txtTelpPengirim.UseSystemPasswordChar = false;
            // 
            // materialLabel5
            // 
            this.materialLabel5.AutoSize = true;
            this.materialLabel5.BackColor = System.Drawing.SystemColors.Window;
            this.materialLabel5.Depth = 0;
            this.materialLabel5.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel5.Location = new System.Drawing.Point(3, 101);
            this.materialLabel5.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel5.Name = "materialLabel5";
            this.materialLabel5.Size = new System.Drawing.Size(94, 19);
            this.materialLabel5.TabIndex = 7;
            this.materialLabel5.Text = "Kota Asal    :";
            // 
            // materialLabel4
            // 
            this.materialLabel4.AutoSize = true;
            this.materialLabel4.BackColor = System.Drawing.SystemColors.Window;
            this.materialLabel4.Depth = 0;
            this.materialLabel4.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel4.Location = new System.Drawing.Point(3, 68);
            this.materialLabel4.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel4.Name = "materialLabel4";
            this.materialLabel4.Size = new System.Drawing.Size(95, 19);
            this.materialLabel4.TabIndex = 6;
            this.materialLabel4.Text = "No Telpon   :";
            // 
            // materialLabel3
            // 
            this.materialLabel3.AutoSize = true;
            this.materialLabel3.BackColor = System.Drawing.SystemColors.Window;
            this.materialLabel3.Depth = 0;
            this.materialLabel3.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel3.Location = new System.Drawing.Point(3, 37);
            this.materialLabel3.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel3.Name = "materialLabel3";
            this.materialLabel3.Size = new System.Drawing.Size(97, 19);
            this.materialLabel3.TabIndex = 5;
            this.materialLabel3.Text = "Nama           :";
            // 
            // materialSingleLineTextField2
            // 
            this.materialSingleLineTextField2.BackColor = System.Drawing.SystemColors.Window;
            this.materialSingleLineTextField2.Depth = 0;
            this.materialSingleLineTextField2.Hint = "";
            this.materialSingleLineTextField2.Location = new System.Drawing.Point(404, 83);
            this.materialSingleLineTextField2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialSingleLineTextField2.Name = "materialSingleLineTextField2";
            this.materialSingleLineTextField2.PasswordChar = '\0';
            this.materialSingleLineTextField2.SelectedText = "";
            this.materialSingleLineTextField2.SelectionLength = 0;
            this.materialSingleLineTextField2.SelectionStart = 0;
            this.materialSingleLineTextField2.Size = new System.Drawing.Size(117, 23);
            this.materialSingleLineTextField2.TabIndex = 10;
            this.materialSingleLineTextField2.UseSystemPasswordChar = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Window;
            this.panel2.Controls.Add(this.txtKodePos);
            this.panel2.Controls.Add(this.materialLabel18);
            this.panel2.Controls.Add(this.txtPenerima);
            this.panel2.Controls.Add(this.txtTujuan);
            this.panel2.Controls.Add(this.txtTlpPenerima);
            this.panel2.Controls.Add(this.materialLabel6);
            this.panel2.Controls.Add(this.materialLabel7);
            this.panel2.Controls.Add(this.materialLabel8);
            this.panel2.Controls.Add(this.materialLabel9);
            this.panel2.Location = new System.Drawing.Point(380, 130);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(259, 180);
            this.panel2.TabIndex = 11;
            // 
            // txtKodePos
            // 
            this.txtKodePos.BackColor = System.Drawing.SystemColors.Window;
            this.txtKodePos.Depth = 0;
            this.txtKodePos.Hint = "";
            this.txtKodePos.Location = new System.Drawing.Point(101, 101);
            this.txtKodePos.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtKodePos.Name = "txtKodePos";
            this.txtKodePos.PasswordChar = '\0';
            this.txtKodePos.SelectedText = "";
            this.txtKodePos.SelectionLength = 0;
            this.txtKodePos.SelectionStart = 0;
            this.txtKodePos.Size = new System.Drawing.Size(117, 23);
            this.txtKodePos.TabIndex = 12;
            this.txtKodePos.UseSystemPasswordChar = false;
            // 
            // materialLabel18
            // 
            this.materialLabel18.AutoSize = true;
            this.materialLabel18.BackColor = System.Drawing.SystemColors.Window;
            this.materialLabel18.Depth = 0;
            this.materialLabel18.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel18.Location = new System.Drawing.Point(3, 101);
            this.materialLabel18.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel18.Name = "materialLabel18";
            this.materialLabel18.Size = new System.Drawing.Size(97, 19);
            this.materialLabel18.TabIndex = 11;
            this.materialLabel18.Text = "Kode Pos     :";
            // 
            // txtPenerima
            // 
            this.txtPenerima.BackColor = System.Drawing.SystemColors.Window;
            this.txtPenerima.Depth = 0;
            this.txtPenerima.Hint = "";
            this.txtPenerima.Location = new System.Drawing.Point(101, 37);
            this.txtPenerima.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtPenerima.Name = "txtPenerima";
            this.txtPenerima.PasswordChar = '\0';
            this.txtPenerima.SelectedText = "";
            this.txtPenerima.SelectionLength = 0;
            this.txtPenerima.SelectionStart = 0;
            this.txtPenerima.Size = new System.Drawing.Size(117, 23);
            this.txtPenerima.TabIndex = 10;
            this.txtPenerima.UseSystemPasswordChar = false;
            // 
            // txtTujuan
            // 
            this.txtTujuan.BackColor = System.Drawing.SystemColors.Window;
            this.txtTujuan.Depth = 0;
            this.txtTujuan.Hint = "";
            this.txtTujuan.Location = new System.Drawing.Point(101, 133);
            this.txtTujuan.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtTujuan.Name = "txtTujuan";
            this.txtTujuan.PasswordChar = '\0';
            this.txtTujuan.SelectedText = "";
            this.txtTujuan.SelectionLength = 0;
            this.txtTujuan.SelectionStart = 0;
            this.txtTujuan.Size = new System.Drawing.Size(117, 23);
            this.txtTujuan.TabIndex = 9;
            this.txtTujuan.UseSystemPasswordChar = false;
            // 
            // txtTlpPenerima
            // 
            this.txtTlpPenerima.BackColor = System.Drawing.SystemColors.Window;
            this.txtTlpPenerima.Depth = 0;
            this.txtTlpPenerima.Hint = "";
            this.txtTlpPenerima.Location = new System.Drawing.Point(101, 68);
            this.txtTlpPenerima.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtTlpPenerima.Name = "txtTlpPenerima";
            this.txtTlpPenerima.PasswordChar = '\0';
            this.txtTlpPenerima.SelectedText = "";
            this.txtTlpPenerima.SelectionLength = 0;
            this.txtTlpPenerima.SelectionStart = 0;
            this.txtTlpPenerima.Size = new System.Drawing.Size(117, 23);
            this.txtTlpPenerima.TabIndex = 8;
            this.txtTlpPenerima.UseSystemPasswordChar = false;
            // 
            // materialLabel6
            // 
            this.materialLabel6.AutoSize = true;
            this.materialLabel6.BackColor = System.Drawing.SystemColors.Window;
            this.materialLabel6.Depth = 0;
            this.materialLabel6.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel6.Location = new System.Drawing.Point(3, 133);
            this.materialLabel6.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel6.Name = "materialLabel6";
            this.materialLabel6.Size = new System.Drawing.Size(97, 19);
            this.materialLabel6.TabIndex = 7;
            this.materialLabel6.Text = "Kota Tujuan :";
            // 
            // materialLabel7
            // 
            this.materialLabel7.AutoSize = true;
            this.materialLabel7.BackColor = System.Drawing.SystemColors.Window;
            this.materialLabel7.Depth = 0;
            this.materialLabel7.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel7.Location = new System.Drawing.Point(3, 68);
            this.materialLabel7.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel7.Name = "materialLabel7";
            this.materialLabel7.Size = new System.Drawing.Size(95, 19);
            this.materialLabel7.TabIndex = 6;
            this.materialLabel7.Text = "No Telpon   :";
            // 
            // materialLabel8
            // 
            this.materialLabel8.AutoSize = true;
            this.materialLabel8.BackColor = System.Drawing.SystemColors.Window;
            this.materialLabel8.Depth = 0;
            this.materialLabel8.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel8.Location = new System.Drawing.Point(3, 37);
            this.materialLabel8.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel8.Name = "materialLabel8";
            this.materialLabel8.Size = new System.Drawing.Size(97, 19);
            this.materialLabel8.TabIndex = 5;
            this.materialLabel8.Text = "Nama           :";
            // 
            // materialLabel9
            // 
            this.materialLabel9.AutoSize = true;
            this.materialLabel9.BackColor = System.Drawing.SystemColors.Window;
            this.materialLabel9.Depth = 0;
            this.materialLabel9.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel9.Location = new System.Drawing.Point(3, 0);
            this.materialLabel9.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel9.Name = "materialLabel9";
            this.materialLabel9.Size = new System.Drawing.Size(111, 19);
            this.materialLabel9.TabIndex = 5;
            this.materialLabel9.Text = "Data Penerima ";
            this.materialLabel9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Window;
            this.panel3.Controls.Add(this.materialLabel15);
            this.panel3.Controls.Add(this.txtBeratBrg);
            this.panel3.Controls.Add(this.materialLabel14);
            this.panel3.Controls.Add(this.txtJnsBrg);
            this.panel3.Controls.Add(this.txtJmlhBrg);
            this.panel3.Controls.Add(this.txtNmaBrg);
            this.panel3.Controls.Add(this.materialLabel10);
            this.panel3.Controls.Add(this.materialLabel11);
            this.panel3.Controls.Add(this.materialLabel12);
            this.panel3.Controls.Add(this.materialLabel13);
            this.panel3.Location = new System.Drawing.Point(34, 291);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(259, 168);
            this.panel3.TabIndex = 11;
            // 
            // materialLabel15
            // 
            this.materialLabel15.AutoSize = true;
            this.materialLabel15.BackColor = System.Drawing.SystemColors.Window;
            this.materialLabel15.Depth = 0;
            this.materialLabel15.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel15.Location = new System.Drawing.Point(176, 137);
            this.materialLabel15.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel15.Name = "materialLabel15";
            this.materialLabel15.Size = new System.Drawing.Size(26, 19);
            this.materialLabel15.TabIndex = 13;
            this.materialLabel15.Text = "Kg";
            // 
            // txtBeratBrg
            // 
            this.txtBeratBrg.BackColor = System.Drawing.SystemColors.Window;
            this.txtBeratBrg.Depth = 0;
            this.txtBeratBrg.Hint = "";
            this.txtBeratBrg.Location = new System.Drawing.Point(116, 133);
            this.txtBeratBrg.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtBeratBrg.Name = "txtBeratBrg";
            this.txtBeratBrg.PasswordChar = '\0';
            this.txtBeratBrg.SelectedText = "";
            this.txtBeratBrg.SelectionLength = 0;
            this.txtBeratBrg.SelectionStart = 0;
            this.txtBeratBrg.Size = new System.Drawing.Size(54, 23);
            this.txtBeratBrg.TabIndex = 12;
            this.txtBeratBrg.UseSystemPasswordChar = false;
            // 
            // materialLabel14
            // 
            this.materialLabel14.AutoSize = true;
            this.materialLabel14.BackColor = System.Drawing.SystemColors.Window;
            this.materialLabel14.Depth = 0;
            this.materialLabel14.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel14.Location = new System.Drawing.Point(3, 133);
            this.materialLabel14.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel14.Name = "materialLabel14";
            this.materialLabel14.Size = new System.Drawing.Size(104, 19);
            this.materialLabel14.TabIndex = 11;
            this.materialLabel14.Text = "Berat              :";
            // 
            // txtJnsBrg
            // 
            this.txtJnsBrg.BackColor = System.Drawing.SystemColors.Window;
            this.txtJnsBrg.Depth = 0;
            this.txtJnsBrg.Hint = "";
            this.txtJnsBrg.Location = new System.Drawing.Point(116, 37);
            this.txtJnsBrg.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtJnsBrg.Name = "txtJnsBrg";
            this.txtJnsBrg.PasswordChar = '\0';
            this.txtJnsBrg.SelectedText = "";
            this.txtJnsBrg.SelectionLength = 0;
            this.txtJnsBrg.SelectionStart = 0;
            this.txtJnsBrg.Size = new System.Drawing.Size(117, 23);
            this.txtJnsBrg.TabIndex = 10;
            this.txtJnsBrg.UseSystemPasswordChar = false;
            // 
            // txtJmlhBrg
            // 
            this.txtJmlhBrg.BackColor = System.Drawing.SystemColors.Window;
            this.txtJmlhBrg.Depth = 0;
            this.txtJmlhBrg.Hint = "";
            this.txtJmlhBrg.Location = new System.Drawing.Point(116, 101);
            this.txtJmlhBrg.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtJmlhBrg.Name = "txtJmlhBrg";
            this.txtJmlhBrg.PasswordChar = '\0';
            this.txtJmlhBrg.SelectedText = "";
            this.txtJmlhBrg.SelectionLength = 0;
            this.txtJmlhBrg.SelectionStart = 0;
            this.txtJmlhBrg.Size = new System.Drawing.Size(117, 23);
            this.txtJmlhBrg.TabIndex = 9;
            this.txtJmlhBrg.UseSystemPasswordChar = false;
            // 
            // txtNmaBrg
            // 
            this.txtNmaBrg.BackColor = System.Drawing.SystemColors.Window;
            this.txtNmaBrg.Depth = 0;
            this.txtNmaBrg.Hint = "";
            this.txtNmaBrg.Location = new System.Drawing.Point(116, 68);
            this.txtNmaBrg.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtNmaBrg.Name = "txtNmaBrg";
            this.txtNmaBrg.PasswordChar = '\0';
            this.txtNmaBrg.SelectedText = "";
            this.txtNmaBrg.SelectionLength = 0;
            this.txtNmaBrg.SelectionStart = 0;
            this.txtNmaBrg.Size = new System.Drawing.Size(117, 23);
            this.txtNmaBrg.TabIndex = 8;
            this.txtNmaBrg.UseSystemPasswordChar = false;
            // 
            // materialLabel10
            // 
            this.materialLabel10.AutoSize = true;
            this.materialLabel10.BackColor = System.Drawing.SystemColors.Window;
            this.materialLabel10.Depth = 0;
            this.materialLabel10.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel10.Location = new System.Drawing.Point(3, 101);
            this.materialLabel10.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel10.Name = "materialLabel10";
            this.materialLabel10.Size = new System.Drawing.Size(106, 19);
            this.materialLabel10.TabIndex = 7;
            this.materialLabel10.Text = "Jumlah           :";
            // 
            // materialLabel11
            // 
            this.materialLabel11.AutoSize = true;
            this.materialLabel11.BackColor = System.Drawing.SystemColors.Window;
            this.materialLabel11.Depth = 0;
            this.materialLabel11.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel11.Location = new System.Drawing.Point(3, 68);
            this.materialLabel11.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel11.Name = "materialLabel11";
            this.materialLabel11.Size = new System.Drawing.Size(107, 19);
            this.materialLabel11.TabIndex = 6;
            this.materialLabel11.Text = "Nama Barang :";
            // 
            // materialLabel12
            // 
            this.materialLabel12.AutoSize = true;
            this.materialLabel12.BackColor = System.Drawing.SystemColors.Window;
            this.materialLabel12.Depth = 0;
            this.materialLabel12.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel12.Location = new System.Drawing.Point(3, 37);
            this.materialLabel12.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel12.Name = "materialLabel12";
            this.materialLabel12.Size = new System.Drawing.Size(107, 19);
            this.materialLabel12.TabIndex = 5;
            this.materialLabel12.Text = "Jenis Barang  :";
            // 
            // materialLabel13
            // 
            this.materialLabel13.AutoSize = true;
            this.materialLabel13.BackColor = System.Drawing.SystemColors.Window;
            this.materialLabel13.Depth = 0;
            this.materialLabel13.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel13.Location = new System.Drawing.Point(3, 0);
            this.materialLabel13.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel13.Name = "materialLabel13";
            this.materialLabel13.Size = new System.Drawing.Size(95, 19);
            this.materialLabel13.TabIndex = 5;
            this.materialLabel13.Text = "Data Kiriman";
            this.materialLabel13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // materialLabel16
            // 
            this.materialLabel16.AutoSize = true;
            this.materialLabel16.BackColor = System.Drawing.SystemColors.Window;
            this.materialLabel16.Depth = 0;
            this.materialLabel16.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel16.Location = new System.Drawing.Point(376, 328);
            this.materialLabel16.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel16.Name = "materialLabel16";
            this.materialLabel16.Size = new System.Drawing.Size(96, 19);
            this.materialLabel16.TabIndex = 14;
            this.materialLabel16.Text = "Harga Total :";
            // 
            // txtHarga
            // 
            this.txtHarga.BackColor = System.Drawing.SystemColors.Window;
            this.txtHarga.Depth = 0;
            this.txtHarga.Hint = "";
            this.txtHarga.Location = new System.Drawing.Point(507, 328);
            this.txtHarga.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtHarga.Name = "txtHarga";
            this.txtHarga.PasswordChar = '\0';
            this.txtHarga.SelectedText = "";
            this.txtHarga.SelectionLength = 0;
            this.txtHarga.SelectionStart = 0;
            this.txtHarga.Size = new System.Drawing.Size(117, 23);
            this.txtHarga.TabIndex = 14;
            this.txtHarga.UseSystemPasswordChar = false;
            // 
            // materialLabel17
            // 
            this.materialLabel17.AutoSize = true;
            this.materialLabel17.BackColor = System.Drawing.SystemColors.Window;
            this.materialLabel17.Depth = 0;
            this.materialLabel17.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel17.Location = new System.Drawing.Point(477, 328);
            this.materialLabel17.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel17.Name = "materialLabel17";
            this.materialLabel17.Size = new System.Drawing.Size(34, 19);
            this.materialLabel17.TabIndex = 14;
            this.materialLabel17.Text = "Rp. ";
            // 
            // btnSimpan
            // 
            this.btnSimpan.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnSimpan.Depth = 0;
            this.btnSimpan.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSimpan.Location = new System.Drawing.Point(375, 407);
            this.btnSimpan.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnSimpan.Name = "btnSimpan";
            this.btnSimpan.Primary = true;
            this.btnSimpan.Size = new System.Drawing.Size(75, 36);
            this.btnSimpan.TabIndex = 15;
            this.btnSimpan.Text = "Simpan";
            this.btnSimpan.UseVisualStyleBackColor = false;
            // 
            // btnBatal
            // 
            this.btnBatal.Depth = 0;
            this.btnBatal.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBatal.Location = new System.Drawing.Point(456, 407);
            this.btnBatal.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnBatal.Name = "btnBatal";
            this.btnBatal.Primary = true;
            this.btnBatal.Size = new System.Drawing.Size(76, 36);
            this.btnBatal.TabIndex = 16;
            this.btnBatal.Text = "Batal";
            this.btnBatal.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(666, 508);
            this.Controls.Add(this.btnBatal);
            this.Controls.Add(this.btnSimpan);
            this.Controls.Add(this.materialLabel17);
            this.Controls.Add(this.txtHarga);
            this.Controls.Add(this.materialLabel16);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.materialSingleLineTextField2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.materialLabel1);
            this.Controls.Add(this.materialSingleLineTextField1);
            this.Controls.Add(this.LabelResi);
            this.Name = "Form1";
            this.Text = "Form Ekspedisi";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MaterialSkin.Controls.MaterialLabel LabelResi;
        private MaterialSkin.Controls.MaterialSingleLineTextField materialSingleLineTextField1;
        private MaterialSkin.Controls.MaterialLabel materialLabel1;
        private MaterialSkin.Controls.MaterialLabel materialLabel2;
        private System.Windows.Forms.Panel panel1;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtNmaPengirim;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtAsal;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtTelpPengirim;
        private MaterialSkin.Controls.MaterialLabel materialLabel5;
        private MaterialSkin.Controls.MaterialLabel materialLabel4;
        private MaterialSkin.Controls.MaterialLabel materialLabel3;
        private MaterialSkin.Controls.MaterialSingleLineTextField materialSingleLineTextField2;
        private System.Windows.Forms.Panel panel2;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtPenerima;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtTujuan;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtTlpPenerima;
        private MaterialSkin.Controls.MaterialLabel materialLabel6;
        private MaterialSkin.Controls.MaterialLabel materialLabel7;
        private MaterialSkin.Controls.MaterialLabel materialLabel8;
        private MaterialSkin.Controls.MaterialLabel materialLabel9;
        private System.Windows.Forms.Panel panel3;
        private MaterialSkin.Controls.MaterialLabel materialLabel15;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtBeratBrg;
        private MaterialSkin.Controls.MaterialLabel materialLabel14;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtJnsBrg;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtJmlhBrg;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtNmaBrg;
        private MaterialSkin.Controls.MaterialLabel materialLabel10;
        private MaterialSkin.Controls.MaterialLabel materialLabel11;
        private MaterialSkin.Controls.MaterialLabel materialLabel12;
        private MaterialSkin.Controls.MaterialLabel materialLabel13;
        private MaterialSkin.Controls.MaterialLabel materialLabel16;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtHarga;
        private MaterialSkin.Controls.MaterialLabel materialLabel17;
        private MaterialSkin.Controls.MaterialRaisedButton btnSimpan;
        private MaterialSkin.Controls.MaterialRaisedButton btnBatal;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtKodePos;
        private MaterialSkin.Controls.MaterialLabel materialLabel18;
    }
}

