﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Double resultValue = 0;
        String operasi = "";
        bool OpePerfom = false;
        bool T = false;


        private void btn1_Click(object sender, EventArgs e)
        {
            if ((txtResult.Text == "0") || (OpePerfom) || T)
                txtResult.Clear();
            OpePerfom = false;
            T = false;
            Button button = (Button)sender;
            if (button.Text == ",")
            {
                if (!txtResult.Text.Contains(","))
                    if (txtResult.Text == "")
                        txtResult.Text = "0" + button.Text;
                    else
                        txtResult.Text = txtResult.Text + button.Text;

            }
            else
                txtResult.Text = txtResult.Text + button.Text;
        }
        private void operator_click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            if (txtResult.Text=="" && button.Text=="-")
            {
                txtResult.Text = txtResult.Text + "-";
            }
            else if (resultValue != 0)
            {
                btnHasil.PerformClick();
                operasi = button.Text;
                label1.Text = resultValue + " " + operasi;
                OpePerfom = true;
            }
            else if (resultValue == 0 && txtResult.Text!="")
            {

                operasi = button.Text;
                resultValue = Double.Parse(txtResult.Text);
                label1.Text = resultValue + " " + operasi;
                OpePerfom = true;
            }
        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtResult.Text = "";
            label1.Text = "";
            resultValue = 0;
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            int lenght = txtResult.TextLength - 1;
            string text = txtResult.Text;
            txtResult.Clear();
            for (int i = 0; i < lenght; i++)
                txtResult.Text = txtResult.Text + text[i];
        }

        public void Hasil_Click(object sender, EventArgs e)
        {
            switch (operasi)
            {
                case "+":
                    txtResult.Text = (resultValue + Double.Parse(txtResult.Text)).ToString();
                    break;
                case "-":
                    txtResult.Text = (resultValue - Double.Parse(txtResult.Text)).ToString();
                    break;
                case "*":
                    txtResult.Text = (resultValue * Double.Parse(txtResult.Text)).ToString();
                    break;
                case "/":
                    txtResult.Text = (resultValue / Double.Parse(txtResult.Text)).ToString();
                    break;
                default:
                    break;
            }
            resultValue = Double.Parse(txtResult.Text);
            label1.Text = "";
            operasi = "";
            T = true;
        }

        private void min_click(object sender, EventArgs e)
        {
            if (txtResult.Text!="")
            {
                txtResult.Text = (-1 * Double.Parse(txtResult.Text)).ToString();
            }
        }
    }
}
